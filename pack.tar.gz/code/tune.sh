export CUDPP_DIR=/home/hongc/PACT2016/gpu_framework/cudpp/cudpp

export CUDPP_LIB=$CUDPP_DIR/lib
export CUDPP_INCLUDE=$CUDPP_DIR/include
export ITER=10


nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBFS  -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE0 -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BFS
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DSSSP  -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE0 -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o SSSP
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBC  -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE0 -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BC
#for j in bfs sssp prd bc bfs_s sssp_s cc_s prd_s bc_s bfs_d sssp_d prd_d prt_d
echo "Testing MultiGraph (hybrid)"
for j in BC BFS SSSP
do
echo "running $j(original node numbering)"
for i in soc-LiveJournal1 soc-orkut hollywood-2009 indochina-2004 rmat24 kron_g500-logn21 rgg_n_2_24_s0 road_usa roadNet-CA
do
echo -n ${i},
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/${i}/${i}.mtx 0 ${ITER}
done
echo
echo "running $j(random re-numbering)"
echo -n soc-LiveJournal1,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/soc-LiveJournal1/soc-LiveJournal1.m2 3266740 ${ITER}
echo -n soc-orkut,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/soc-orkut/soc-orkut.m2 17047 ${ITER}
echo -n hollywood-2009,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/hollywood-2009/hollywood-2009.m2 775106 ${ITER}
echo -n indochina-2004,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/indochina-2004/indochina-2004.m2 6750856 ${ITER}
echo -n rmat24,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/rmat24/rmat24.m2 0 ${ITER}
echo -n road_usa,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/road_usa/road_usa.m2 15916361 ${ITER}
echo -n rgg_n_2_24_s0,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/rgg_n_2_24_s0/rgg_n_2_24_s0.m2 8934858 ${ITER}
echo -n kron_g500-logn21,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/kron_g500-logn21/kron_g500-logn21.m2 495356 ${ITER}
echo -n roadNet-CA,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/roadNet-CA/roadNet-CA.m2 1916604 ${ITER}
echo
done
echo


