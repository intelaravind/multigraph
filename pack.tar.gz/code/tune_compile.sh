export CUDPP_DIR=/home/hongc/PACT2016/gpu_framework/cudpp/cudpp

export CUDPP_LIB=$CUDPP_DIR/lib
export CUDPP_INCLUDE=$CUDPP_DIR/include


#nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBFS  -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BFS
#nvcc -O3 -gencode arch=compute_35,code=sm_35 -DSSSP  -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o SSSP
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBC  -DPRINT_OUTPUT0 -DVALIDATE -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BC
#for j in bfs sssp prd bc bfs_s sssp_s cc_s prd_s bc_s bfs_d sssp_d prd_d prt_d


