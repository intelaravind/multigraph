export CUDPP_DIR=/home/hongc/PACT2016/gpu_framework/cudpp/cudpp

export CUDPP_LIB=$CUDPP_DIR/lib
export CUDPP_INCLUDE=$CUDPP_DIR/include


nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBFS -DSPARSE_MODE -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BFS_SPARSE
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DSSSP -DSPARSE_MODE -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o SSSP_SPARSE
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBC -DSPARSE_MODE -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BC_SPARSE

nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBFS -DDENSE_MODE -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BFS_DENSE
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DSSSP -DDENSE_MODE -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o SSSP_DENSE
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBC -DDENSE_MODE -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BC_DENSE

nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBFS  -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BFS
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DSSSP  -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o SSSP
nvcc -O3 -gencode arch=compute_35,code=sm_35 -DBC  -DPRINT_OUTPUT0 -DVALIDATE0 -DSYM -DTRACE -lcudpp --use_fast_math -Xptxas "-v -dlcm=cg" -I${CUDPP_INCLUDE} -L${CUDPP_LIB} read_input.cu function.cu gen_structure.cu release_structure.cu process.cu process2.cu processi.cu validate.cu main.cu -o BC

#for j in bfs sssp prd bc bfs_s sssp_s cc_s prd_s bc_s bfs_d sssp_d prd_d prt_d
echo "Testing MultiGraph (hybrid)"
for j in BFS_DENSE BC_DENSE SSP_DENSE 
do
echo "running $j(original node numbering)"
for i in soc-LiveJournal1 soc-orkut hollywood-2009 indochina-2004 rmat24 kron_g500-logn21 rgg_n_2_24_s0 road_usa roadNet-CA
do
echo -n ${i},
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/${i}/${i}.mtx 0 1
done
echo
echo "running $j(random re-numbering)"
echo -n soc-LiveJournal1,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/soc-LiveJournal1/soc-LiveJournal1.m2 3266740 1
echo -n soc-orkut,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/soc-orkut/soc-orkut.m2 17047 1 
echo -n hollywood-2009,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/hollywood-2009/hollywood-2009.m2 775106 1
echo -n indochina-2004,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/indochina-2004/indochina-2004.m2 6750856 1 
echo -n rmat24,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/rmat24/rmat24.m2 0 1
echo -n kron_g500-logn21,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/kron_g500-logn21/kron_g500-logn21.m2 495356 1 
echo -n rgg_n_2_24_s0,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/rgg_n_2_24_s0/rgg_n_2_24_s0.m2 8934858 1 
echo -n road_usa,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/road_usa/road_usa.m2 15916361 1
echo -n roadNet-CA,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/roadNet-CA/roadNet-CA.m2 1916604 1
echo
done
echo

echo "Testing MultiGraphS (sparse)"
for j in BC_SPARSE BFS_SPARSE CC_SPARSE DATA_DRIVEN_PR_SPARSE SSSP_SPARSE
do
echo "running $j(original node numbering)"
for i in soc-LiveJournal1 soc-orkut hollywood-2009 indochina-2004 rmat24 road_usa rgg_n_2_24_s0 kron_g500-logn21 roadNet-CA
do
echo -n ${i},
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/${i}/${i}.mtx 0 10 
done
echo
echo "running $j(random re-numbering)"
echo -n soc-LiveJournal1,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/soc-LiveJournal1/soc-LiveJournal1.m2 3266740 10 
echo -n soc-orkut,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/soc-orkut/soc-orkut.m2 17047 10 
echo -n hollywood-2009,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/hollywood-2009/hollywood-2009.m2 775106 10 
echo -n indochina-2004,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/indochina-2004/indochina-2004.m2 6750856 10 
echo -n rmat24,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/rmat24/rmat24.m2 0 10 
echo -n road_usa,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/road_usa/road_usa.m2 15916361 10 
echo -n rgg_n_2_24_s0,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/rgg_n_2_24_s0/rgg_n_2_24_s0.m2 8934858 10 
echo -n kron_g500-logn21,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/kron_g500-logn21/kron_g500-logn21.m2 495356 10 
echo -n roadNet-CA,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/roadNet-CA/roadNet-CA.m2 1916604 10 
echo
done
echo

echo "Testing MultiGraphD (dense)"
for j in BC_DENSE BFS_DENSE DATA_DRIVEN_PR_DENSE TOPOLOGY_DRIVEN_PR_DENSE SSSP_DENSE
do
echo "running $j(original node numbering)"
for i in soc-LiveJournal1 soc-orkut hollywood-2009 indochina-2004 rmat24 road_usa rgg_n_2_24_s0 kron_g500-logn21 roadNet-CA
do
echo -n ${i},
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/${i}/${i}.mtx 0 10 
done
echo
echo "running $j(random re-numbering)"
echo -n soc-LiveJournal1,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/soc-LiveJournal1/soc-LiveJournal1.m2 3266740 10 
echo -n soc-orkut,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/soc-orkut/soc-orkut.m2 17047 10 
echo -n hollywood-2009,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/hollywood-2009/hollywood-2009.m2 775106 10 
echo -n indochina-2004,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/indochina-2004/indochina-2004.m2 6750856 10 
echo -n rmat24,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/rmat24/rmat24.m2 0 10 
echo -n road_usa,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/road_usa/road_usa.m2 15916361 10 
echo -n rgg_n_2_24_s0,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/rgg_n_2_24_s0/rgg_n_2_24_s0.m2 8934858 10 
echo -n kron_g500-logn21,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/kron_g500-logn21/kron_g500-logn21.m2 495356 10 
echo -n roadNet-CA,
./${j} /home/hongc/PACT2016/gpu_framework/gunrock2/gunrock/dataset/large/roadNet-CA/roadNet-CA.m2 1916604 10 
echo
done

